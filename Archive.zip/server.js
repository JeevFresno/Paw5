/**
 * Created by Jeevjyot on 4/14/17.
 */


var express = require('express');

var app = express();
console.log(__dirname);
//app.use('/', express.static(__dirname + '/public/html/index.html'));

app.use('/', express.static(__dirname + '/public/html/'));
/*app.get('/',function(req,res){
    res.send('Hello World');
})*/

var port = process.env.PORT || 3000;
var server = app.listen(port,function(req,res){
    console.log('Hello World');
    //res.send('Hello World');
})